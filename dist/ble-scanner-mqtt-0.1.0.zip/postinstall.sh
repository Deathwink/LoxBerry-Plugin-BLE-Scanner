#!/bin/sh
set -eu
PDIR="$3"
PCONFIG="$LBPCONFIG/$PDIR"
VENV="$PCONFIG/venv"
[ -x "$VENV/bin/python" ] || python3 -m venv "$VENV"
"$VENV/bin/python" -m pip install --disable-pip-version-check --no-cache-dir \
    'bleak==0.22.3' 'paho-mqtt==2.1.0'
chmod 755 "$VENV"
exit 0
