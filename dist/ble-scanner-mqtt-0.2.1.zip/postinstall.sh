#!/bin/sh
set -eu
PDIR="$3"
PCONFIG="$LBPCONFIG/$PDIR"
VENV="$PCONFIG/venv"
SCRIPT_DIR="$(CDPATH='' cd "$(dirname "$0")" && pwd)"

mkdir -p "$PCONFIG"
if [ ! -f "$PCONFIG/pluginconfig.json" ]; then
    cp "$SCRIPT_DIR/defaults/pluginconfig.json" "$PCONFIG/pluginconfig.json"
    chmod 644 "$PCONFIG/pluginconfig.json"
fi

[ -x "$VENV/bin/python" ] || python3 -m venv "$VENV"
"$VENV/bin/python" -m pip install --disable-pip-version-check --no-cache-dir \
    'bleak==0.22.3' 'paho-mqtt==2.1.0'
chmod 755 "$VENV"
chown -R loxberry:loxberry "$PCONFIG" 2>/dev/null || true
exit 0
